﻿using Microsoft.Maps.MapControl.WPF;
using Microsoft.Maps.MapControl.WPF.Design;
using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Timers;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace CAARS
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        
        string crashID;
        string latitude;
        string longitude;
        int speed;
        string speedString;
        string dateTime;
        public MainWindow()
        {
            //Initialize the wpf window
            InitializeComponent();
            //Set the date label to the correct date
            date.Content = DateTime.Now.ToLocalTime().ToString("yyyy-MM-dd");
            //Load the mySQL data
            PullData();
            //Start the refresh timer
            refreshTimer();

        }
        private void refreshTimer()
        {
            
            //Set a time to refresh the data every 5 seconds
            Timer myTimer = new Timer(5000);
            myTimer.Elapsed += new ElapsedEventHandler(Refresh);
            myTimer.Start();
            Console.WriteLine("not refreshing");
        }

        public void Refresh(object source, ElapsedEventArgs e)
        {

            this.Dispatcher.Invoke(() =>
            {
                var table = new DataTable();
                using (var da = new MySqlDataAdapter("SELECT * FROM CrashData", "Server= 192.168.2.20; Database=SoftwareDev;UID=root;Password=raspberry;Allow Zero Datetime=True;Convert Zero Datetime=True"))
                {
                    //Fill a DataTable with the exact information (Columns and Rows) from the mySQL database
                    //table.Clear();
                    da.Fill(table);
                    crashData.ItemsSource = table.DefaultView;
                    crashData.IsReadOnly = true;
                    crashData.CanUserAddRows = false;

                }
                Console.WriteLine("Refreshing");
            });
            
        }
        
        private void logOut_Click(object sender, RoutedEventArgs e)
        {
            //Close the program if the "log out" button is clicked
            this.Close();
        }

        public void PullData()
        {
            var table = new DataTable();
            try
            {
                
                using (var da = new MySqlDataAdapter("SELECT * FROM CrashData", "Server= 192.168.2.20; Database=SoftwareDev;UID=root;Password=raspberry;Allow Zero Datetime=True;Convert Zero Datetime=True"))
                {
                    //Fill a DataTable with the exact information (Columns and Rows) from the mySQL database
                    da.Fill(table);
                    crashData.ItemsSource = table.DefaultView;
                    crashData.IsReadOnly = true;
                    crashData.CanUserAddRows = false;

                }
            }
            catch (MySqlException ex)
            {
                //Catch any possible exceptions when trying to connect to the mySQL database
                Console.WriteLine("Caught MySqlException " + ex.Number);
                Console.WriteLine("Stacktrace " + ex.StackTrace);
                switch (ex.Number)
                {
                    case 0:
                        //A mySQl exception of 0 means there is a problem with the connection string or server
                        Console.WriteLine("Can not connect to server. Check address. Exception: " + ex.Number);
                        this.Close();
                        break;
                    case 1045:
                        //A mysql exception of 1045 means the credentials of the connection string are incorrect
                        Console.WriteLine("Invalid username/password. Exception: " + ex.Number);
                        this.Close();
                        break;
                    default:
                        //If the exception is not of case 0 or 1045 print the unhandled exception number
                        Console.WriteLine("Unhandled Exception " + ex.Number);
                        this.Close();
                        break;

                }
            }
            catch (Exception e)
            {
                //If the exception is not handeled print the stack trace
                Console.WriteLine("Unhandled exception " + e.StackTrace);

            }

        }

        private void dataGrid_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            object item = crashData.SelectedItem;

            if (crashData.SelectedItem != null)
            {
                //Get values of selected row      
                crashID = (crashData.SelectedCells[0].Column.GetCellContent(item) as TextBlock).Text;
                latitude = (crashData.SelectedCells[1].Column.GetCellContent(item) as TextBlock).Text;
                longitude = (crashData.SelectedCells[2].Column.GetCellContent(item) as TextBlock).Text;
                speedString = (crashData.SelectedCells[3].Column.GetCellContent(item) as TextBlock).Text;
                dateTime = (crashData.SelectedCells[5].Column.GetCellContent(item) as TextBlock).Text;
                speed = Convert.ToInt32(speedString);

               

                //set detail grid visible
                detailGrid.Visibility = Visibility.Visible;
                webGrid.Visibility = Visibility.Visible;
                //Set labels to data from database
                IDLabel.Content = "Crash ID: " + crashID;
                latitudeLabel.Content = "Latitude: " + latitude;
                longitudeLabel.Content = "Longitude: " + longitude;
                dateTimeLabel.Content = dateTime;
                speedLabel.Content = "Speed: " + speed+" mph";
                LoadMap(latitude, longitude);

                //Analyze severity of accident
                if (speed >= 0 && speed <= 35)
                {
                    //Set the color if severity is mild (less than 35mph)
                    severityLabel.Content = "Severity: Mild";
                    severityLabel.Background = Brushes.Green;
                }
                else if (speed > 35 && speed <= 55)
                {
                    //Set the color if severity is moderate (greater than 35mph and less than 55mph)
                    severityLabel.Content = "Severity: Moderate";
                    severityLabel.Foreground = Brushes.Black;
                    severityLabel.Background = Brushes.Yellow;
                }
                else if (speed > 55)
                {
                    //Set the color if severity is severe (greater than 55 mph)
                    severityLabel.Content = "Severity: Severe";
                    severityLabel.Background = Brushes.Red;
                }

            }

        }
        private void RefreshLabels()
        {
            //Empty the content of the labels
            IDLabel.Content = "";
            latitudeLabel.Content = "";
            longitudeLabel.Content = "";
        }
        private void LoadMap(String lat, String lon)
        {
            //Drop a map pin on the location of the crash
            Location crashLocation = new Location(Convert.ToDouble(lat), Convert.ToDouble(lon));
            Pushpin crashPin = new Pushpin();
            MapLayer.SetPosition(crashPin, crashLocation);
            map.Children.Add(crashPin);
            map.Mode = new AerialMode(true);
            map.Center = crashLocation;
            map.ZoomLevel = 15;

        }

        private void finishButton_Click(object sender, RoutedEventArgs e) //Remove current item when the finished button is clicked
        {
            //Pull up confirm options
            detailGrid.Visibility = Visibility.Hidden;
            confirmGrid.Visibility = Visibility.Visible;
            webGrid.Visibility = Visibility.Hidden;

        }

        private void confirmButton_Click(object sender, RoutedEventArgs e)
        {
            //If the confirm button is clicked refresh the data and remove the current row
            //This is where, in future versions, we will move the current row from our CrashData table into an ArchievedData table.
            using (MySqlConnection conn = new MySqlConnection("Server= 192.168.2.20; Database=SoftwareDev;UID=root;Password=raspberry"))
            {
                conn.Open();
                using (MySqlCommand cmd = new MySqlCommand("DELETE from CrashData where id = " + crashID, conn))
                {
                    cmd.ExecuteNonQuery();
                }
                PullData();
                RefreshLabels();
                conn.Close();
            }
            detailGrid.Visibility = Visibility.Hidden;
            confirmGrid.Visibility = Visibility.Hidden;
        }

        private void cancelButton_Click(object sender, RoutedEventArgs e)
        {
            //If cancel button is clicked go back to detail view
            confirmGrid.Visibility = Visibility.Hidden;
            detailGrid.Visibility = Visibility.Visible;
        }
    }
}
